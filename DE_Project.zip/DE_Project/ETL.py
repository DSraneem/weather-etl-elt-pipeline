import pandas as pd
import sqlite3
import requests
from datetime import datetime, timedelta
import os
import time
from functools import lru_cache

# ---------- الإعدادات ----------
CSV_FILE_PATH5 = r"C:\\Users\\ReeAl\\venv\\seattle-weather.csv"
API_KEY5 = "6T5FD2NRB9MHDTXC6L7PLTGL2"
NEW_DB_PATH5 = r"C:/sqlite/seattle_weather_database_v5.db"
TABLE_NAME5 = "weather_data5"

# ---------- API الآمن ----------
def safe_api_request5(url5, max_retries=3, delay=10):
    for attempt5 in range(max_retries):
        try:
            response5 = requests.get(url5, timeout=15)
            response5.raise_for_status()
            return response5.json()
        except requests.exceptions.HTTPError as e5:
            if response5.status_code == 429:
                print(f" Rate limit exceeded. Waiting {delay}s... (Attempt {attempt5 + 1}/{max_retries})")
                time.sleep(delay)
            else:
                print(f" API Error: {e5}")
                return None
        except Exception as e5:
            print(f" Unexpected error: {e5}")
            return None
    print(" Failed after multiple retries")
    return None

@lru_cache(maxsize=10)
def fetch_historical_data5(city5, start_date5, end_date5):
    base_url5 = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline"
    url5 = f"{base_url5}/{city5}/{start_date5}/{end_date5}?key={API_KEY5}&unitGroup=metric"
    return safe_api_request5(url5)

# ---------- استخراج CSV ----------
def extract_csv5(file_path5):
    try:
        df5 = pd.read_csv(file_path5)
        print(f" Extracted {len(df5)} rows from CSV")
        if 'humidity' in df5.columns:
            df5['humidity'] = df5['humidity'].round(1)
        return df5
    except Exception as e5:
        print(f" Error reading CSV file: {e5}")
        return pd.DataFrame()

# ---------- استخراج من API ----------
def extract_api5(city5="Riyadh", days5=7):
    end_date5 = datetime.now().strftime('%Y-%m-%d')
    start_date5 = (datetime.now() - timedelta(days=days5)).strftime('%Y-%m-%d')

    data5 = fetch_historical_data5(city5, start_date5, end_date5)
    if not data5:
        return pd.DataFrame()

    records5 = []
    for day5 in data5.get('days', []):
        records5.append({
            'date': day5['datetime'],
            'city': data5.get('address', city5),
            'temp_max': day5.get('tempmax'),
            'temp_min': day5.get('tempmin'),
            'wind_speed': day5.get('windspeed'),
            'weather_condition': day5.get('conditions', 'Unknown'),
            'humidity': round(day5.get('humidity', 0), 1),
            'precipitation': day5.get('precip', 0),
            'source': 'API'
        })

    print(f" Extracted {len(records5)} days from API")
    return pd.DataFrame(records5)

# ---------- تنظيف ودمج البيانات ----------
def clean_data5(csv_df5, api_df5):
    dfs5 = []

    if not csv_df5.empty:
        csv_df5 = csv_df5.rename(columns={
            'weather': 'weather_condition',
            'wind': 'wind_speed'
        })
        csv_df5['source'] = 'CSV'
        csv_df5['city'] = 'Seattle'
        if 'humidity' in csv_df5.columns:
            csv_df5['humidity'] = csv_df5['humidity'].round(1)
        dfs5.append(csv_df5)

    if not api_df5.empty:
        dfs5.append(api_df5)

    if not dfs5:
        print("No data to clean")
        return pd.DataFrame()

    combined5 = pd.concat(dfs5, ignore_index=True)

    required_columns5 = ['date', 'city', 'temp_max', 'temp_min', 'wind_speed',
                         'precipitation', 'weather_condition', 'humidity', 'source']

    for col5 in required_columns5:
        if col5 not in combined5.columns:
            combined5[col5] = None

    combined5['humidity'] = combined5['humidity'].fillna(
        round(combined5['humidity'].mean(), 1) if not combined5['humidity'].isnull().all() else 0.0
    )

    combined5['humidity'] = combined5['humidity'].round(1)

    combined5['date'] = pd.to_datetime(combined5['date']).dt.strftime('%Y-%m-%d')

    print(f"\nCleaned and merged data. Total rows: {len(combined5)}")
    return combined5[required_columns5]

# ---------- التحميل إلى قاعدة البيانات ----------
def load_data5(df5, db_path5):
    try:
        os.makedirs(os.path.dirname(db_path5), exist_ok=True)
        with sqlite3.connect(db_path5) as conn5:
            df5.to_sql(TABLE_NAME5, conn5, if_exists='replace', index=False)
        print(f" Loaded {len(df5)} rows into {db_path5}")
    except Exception as e5:
        print(f"Error loading to database: {e5}")

# ---------- تحليل البيانات ----------
def analyze_data5(df5):
    if df5.empty:
        print(" No data to analyze")
        return

    print("\n Weather Data Analysis")
    print(f"Date range: {df5['date'].min()} to {df5['date'].max()}")
    print(f"Total records: {len(df5)}")
    print("\nSource counts:")
    print(df5['source'].value_counts())
    print("\nTemperature stats:")
    print(f"Avg Max Temp: {df5['temp_max'].mean():.1f}°C")
    print(f"Avg Min Temp: {df5['temp_min'].mean():.1f}°C")
    print("\nHumidity Sample (1 decimal):")
    print(df5[['date', 'humidity']].head().to_string(index=False))

# ---------- Main ----------
def main5():
    print(" Starting Weather ETL v5")

    csv_data5 = extract_csv5(CSV_FILE_PATH5)
    api_data5 = extract_api5()
    cleaned_data5 = clean_data5(csv_data5, api_data5)

    if not cleaned_data5.empty:
        load_data5(cleaned_data5, NEW_DB_PATH5)
        analyze_data5(cleaned_data5)
        cleaned_data5.to_csv("weather_historical_cleaned_v5.csv", index=False)
        print("\n Saved cleaned data to weather_historical_cleaned_v5.csv")
    else:
        print(" No data available after cleaning")

    print("\n ETL v5 process completed")

# ---------- تنفيذ ----------
if __name__ == "__main__":
    main5()