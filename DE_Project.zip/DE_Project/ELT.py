import pandas as pd
import sqlite3
import great_expectations as ge
from sqlalchemy import create_engine

# --- Extract from SQLite (your custom weather source) ---
sqlite_conn = sqlite3.connect("C:/sqlite/ELT.db")  # use your actual db name
df_sqlite = pd.read_sql_query("SELECT * FROM sql_weather", sqlite_conn)
sqlite_conn.close()

# --- Extract from CSV ---
df_csv = pd.read_csv("C:/Users/sw554/venv/seattle_weather.csv")

# Wrap with Great Expectations
ge_sqlite = ge.from_pandas(df_sqlite)
ge_csv = ge.from_pandas(df_csv)

# Example expectations
ge_sqlite.expect_column_values_to_not_be_null("date")
ge_sqlite.expect_column_values_to_be_between("humidity", 0, 100)

ge_csv.expect_column_values_to_not_be_null("date")
ge_csv.expect_column_values_to_be_between("precipitation", 0, 500)

# Validate
print("SQLite Validation:")
print(ge_sqlite.validate())

print("\nCSV Validation:")
print(ge_csv.validate())

valid_sqlite = ge_sqlite.validate()["success"]
valid_csv = ge_csv.validate()["success"]

if valid_sqlite and valid_csv:
    engine = create_engine("postgresql+psycopg2://postgres:ds123@localhost:5432/DE")

    df_sqlite.to_sql("staging_sqlite_weather", engine, if_exists="replace", index=False)
    df_csv.to_sql("staging_csv_weather", engine, if_exists="replace", index=False)

    print("✅ Data successfully loaded into PostgreSQL staging tables.")
else:
    print("❌ Validation failed. No data loaded.")